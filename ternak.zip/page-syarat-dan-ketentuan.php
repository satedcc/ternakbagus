<?php
session_start();
$sid = session_id();

if (isset($_SESSION['id'])) {
    get_header();

?>

    <section id="dashboard" class="dashboard">
        <div class="container">
            <div class="row">
                <?php include "left-navbar.php"; ?>
                <div class="col-md-9">
                    <h1 class="f-20 mb-3">Syarat dan Ketentuan</h1>
                    <div class="content-utama p-4">
                        <h1 class="f-18">Selamat datang di www.ternakbagus.com</h1>
                        <p>Disarankan sebelum mengakses Situs ini lebih jauh, anda terlebih dahulu membaca dan memahami syarat dan ketentuan yang berlaku. Syarat dan ketentuan berikut adalah ketentuan dalam pengunjungan Situs, isi dan/atau konten, layanan, serta fitur lainnya yang ada di dalam Situs. Dengan mengakses atau menggunakan Situs atau aplikasi lainnya yang disediakan oleh atau dalam Situs, berarti Anda telah memahami dan menyetujui serta terikat dan tunduk dengan segala syarat dan ketentuan yang berlaku di Situs ini.
                        </p>
                        <h2 class="bold-md f-14">1. DEFINISI</h2>
                        <p>Setiap kata atau istilah berikut yang digunakan di dalam Syarat dan Ketentuan ini memiliki arti seperti berikut di bawah, kecuali jika kata atau istilah yang bersangkutan di dalam pemakaiannya dengan tegas menentukan lain</p>
                        <p>“Kami”, berarti pemilik dan pengelola Situs serta aplikasi mobile yang bernama TernakBagus.
                        </p>
                        <p>“Anda”, berarti tiap orang yang mengakses Situs dan menggunakan layanan dan jasa yang disediakan oleh Kami.
                        </p>
                        <p>“Layanan”, berarti setiap dan keseluruhan jasa serta informasi yang ada pada Situs, termasuk namun tidak terbatas pada informasi yang disediakan, fitur dan layanan aplikasi, dukungan data, serta aplikasi mobile yang Kami sediakan.
                        </p>
                        <p>“Pengguna”, berarti tiap orang yang mengakses dan menggunakan layanan dan jasa yang disediakan oleh Kami, termasuk diantaranya Pengguna Belum Terdaftar dan Pengguna Terdaftar.
                        </p>
                        <p>"Pengguna Belum Terdaftar", berarti tiap orang yang mengakses Situs Kami dan belum melakukan registrasi.
                        </p>
                        <p>“Pengguna Terdaftar”, berarti tiap orang yang mengakses dan menggunakan layanan dan jasa yang disediakan oleh Kami, serta telah melakukan registrasi dan memiliki akun pada Situs Kami.
                        </p>
                        <p>“Pihak Ketiga”, berarti pihak lainnya yang ada hubungannya dengan TernakBagus dan seluruh layanannya.
                        </p>
                        <p>“Informasi Pribadi”, berarti tiap dan seluruh data pribadi yang diberikan oleh Pengguna di Situs Kami, termasuk namun tidak terbatas pada nama, email, nomor HP, password sebagaimana diminta pada ringkasan pendaftaran akun serta pada ringkasan aplikasi pengajuan.
                        </p>
                        <p>“Konten”, berarti teks, data, informasi, angka, gambar, grafik, foto, audio, video, nama pengguna, informasi, aplikasi, tautan, komentar, peringkat, desain, atau materi lainnya yang ditampilkan pada Situs.
                        </p>
                        <h2 class="bold-md f-14 mt-5">2. LAYANAN & JASA</h2>
                        <p>Kami memberikan informasi dan sarana untuk kegiatan pemasangan iklan penjualan kategori ternak antara lain sapi, kerbau, kambing, domba, unggas termasuk ayam, bebek, kemudian kelinci, perlengkapan ternak dan jasa pendukung kegiatan ternak . Layanan ini memungkinkan Anda untuk meningkatkan kegiatan jual beli hewan ternak secara cepat mudah dan dekat.
                        </p>
                        <p>2.1. Informasi yang terdapat dalam Situs Kami ditampilkan sesuai keadaan kenyataan untuk tujuan informasi umum. Kami berusaha untuk selalu menyediakan dan menampilkan informasi yang terbaru dan akurat, namun Kami tidak menjamin bahwa segala informasi sesuai dengan ketepatan waktu atau relevansi dengan kebutuhan Anda.</p>
                        <p>2.2. Informasi di Situs ini disediakan untuk membantu Anda dalam memilih produk atau layanan yang sesuai dengan kebutuhan Anda. Anda sepenuhnya bertanggung jawab atas keputusan terkait pemilihan produk dan layanan.
                        </p>
                        <p>2.3. Tidak ada situasi atau keadaan apapun yang dapat membuat Kami dikenakan tanggung jawab atas kemungkinan kerugian yang Anda alami karena pengambilan keputusan yang dilakukan oleh Anda sendiri terkait tindakan atas informasi produk yang kami sampaikan di Situs.
                        </p>
                        <p>2.4. Kami memiliki hak untuk kapan saja menampilkan, mengubah, menghapus, menghilangkan, atau menambahkan segala konten yang ditampilkan dalam Situs ini.
                        </p>
                        <h2 class="bold-md f-14 mt-5">3. PENGGUNAAN LAYANAN DAN JASA</h2>
                        <p>Dengan Anda melanjutkan penggunaan atau pengaksesan Situs ini, berarti Anda telah menyatakan serta menjamin kepada Kami bahwa :
                        </p>
                        <p>
                            3.1. Situs ini hanya boleh diakses dan digunakan secara langsung oleh individu atau bisnis yang sedang mencari produk atau layanan untuk individu atau bisnis tersebut.

                        </p>
                        <p>3.2. Anda tidak diperkenankan menggunakan Situs dalam hal sebagai berikut :
                            <ul>
                                <li>1. Untuk menyakiti, menyiksa, mempermalukan, memfitnah, mencemarkan nama baik, mengancam, mengintimidasi atau mengganggu orang atau bisnis lain, atau apapun yang melanggar privasi atau yang Kami anggap cabul, menghina, penuh kebencian, tidak senonoh, tidak patut, tidak pantas, tidak dapat diterima, mendiskriminasikan atau merusak.
                                </li>
                                <li>2. Dalam cara yang melawan hukum, tindakan penipuan atau tindakan komersil.
                                </li>
                                <li>3. Melanggar atau menyalahi hak orang lain, termasuk tanpa kecuali : hak paten, merek dagang, hak cipta, rahasia dagang, publisitas, dan hak milik lainnya
                                </li>
                                <li>
                                    4. Untuk membuat, memeriksa, memperbarui, mengubah atau memperbaiki database, rekaman atau direktori Anda ataupun orang lain.
                                </li>
                                <li>
                                    5. Mengubah atau mengatur ulang bagian apapun dalam Situs ini yang akan mengganggu atau menaruh beban berlebihan pada sistem komunikasi dan teknis kami.

                                </li>
                                <li>
                                    6. Mengunakan kode komputer otomatis, proses, program, robot, net crawler, spider, pemrosesan data, trawling atau kode komputer, proses, program atau sistem screen scraping alternatif.

                                </li>
                                <li>
                                    7. Melanggar Syarat dan Ketentuan, atau petunjuk lainnya yang ada pada Situs.

                                </li>
                            </ul>
                        </p>
                        <p>3.3. Kami tidak bertanggung jawab atas kehilangan akibat kegagalan mengakses Situs, dan metode penggunaan Situs yang diluar kendali Kami.</p>
                        <p>3.4. Kami tidak bertanggung jawab atau tidak dapat dipersalahkan atas kehilangan atau kerusakan yang diluar perkiraan saat Anda mengakses atau menggunakan Situs ini. Ini termasuk kehilangan penghematan yang diharapkan, kehilangan bisnis atau kesempatan bisnis, kehilangan pemasukan atau keuntungan, atau kehilangan atau kerusakan apapun yang Anda harus alami akibat penggunaan Situs ini.</p>
                        <h2 class="bold-md f-14 mt-5">4. HAK INTELEKTUAL PROPERTI</h2>
                        <p>Semua Hak Kekayaan Intelektual yang ada di dalam Situs ini adalah milik Kami. Tiap atau keseluruhan informasi dan materi dan konten, termasuk namun tidak terbatas pada tulisan, perangkat lunak, teks, data, grafik, gambar, audio, video, logo, ikon atau kode-kode html dan kode-kode lain yang ada di Situs ini dilarang dipublikasikan, dimodifikasi, disalin, digandakan atau diubah dengan cara apapun di luar area Situs ini tanpa izin dari Kami. Pelanggaran terhadap hak-hak Situs ini dapat ditindak sesuai dengan peraturan yang berlaku.
                        </p>
                        <h2 class="bold-md f-14 mt-5">5. KOMENTAR</h2>
                        <p>Jika Anda ingin memberikan komentar, masukan, ataupun sanggahan mengenai tiap atau keseluruhan konten dan informasi dalam Situs, Kami juga menyediakan sarana chat/messaging, kontak email, blog, ataupun media sosial milik Kami. Anda diperbolehkan untuk memberi komentar, dan setuju bahwa jika diperlukan, akan Kami pergunakan untuk kepentingan informasi dan ditampilkan pada Situs Kami. Dan harap diperhatikan bahwa komentar, masukan, atau sanggahan yang Anda berikan tidak boleh bertentangan dengan Syarat dan Ketentuan ini, terutama seperti tercantum dalam poin 3.2.
                        </p>
                        <h2 class="bold-md f-14 mt-5">6. TAUTAN LAINNYA
                        </h2>
                        <p>Situs Kami mungkin menyediakan beberapa tautan tertentu yang merujuk atau mengarahkan Anda ke laman dari situs Pihak Ketiga, juga termasuk di dalamnya tautan yang tersedia pada halaman hasil pencarian produk tertentu. Anda mengetahui, memahami, serta menyetujui bahwa Kami tidak bertanggung jawab atas konten dan/atau materi lainnya yang terdapat dalam tautan milik Pihak Ketiga tersebut. Anda bertanggung jawab atas resiko ketika mengakses dan menggunakan tautan milik Pihak Ketiga tersebut. Dan disarankan Anda juga dapat membaca serta memahami isi dari Syarat dan Ketentuan yang berlaku di tautan milik Pihak Ketiga tersebut.</p>
                        <h2 class="bold-md f-14 mt-5">7. ATURAN KEANGGOTAAN
                        </h2>
                        <p>juga menyediakan keanggotaan bagi Anda selaku Pengguna. Anda dapat memeriksa riwayat keuangan Anda dan juga menemukan produk yang sesuai dengan profil Anda.</p>
                        <p>7.1. Sebelum menjadi anggota (atau disebut dengan Pengguna Terdaftar), Anda diwajibkan membuat akun untuk diri Anda. Proses pembuatan akun dapat dilakukan secara online melalui Situs.</p>
                        <p>7.2. Sebelum menjadi Pengguna Terdaftar, Anda diwajibkan membaca, memahami, dan mematuhi Syarat dan Ketentuan serta Kebijakan Privasi yang berlaku di Situs.</p>
                        <p>7.3. Anda diharuskan memberi data Informasi Pribadi yang sebenarnya dan tidak memberikan informasi menyimpang dan/atau informasi yang tidak relevan dalam melakukan proses registrasi menjadi Pengguna Terdaftar. Selain itu Anda juga diharuskan memberi kontak detail yang benar dan valid.</p>
                        <p>7.4. Kami berhak untuk tidak memproses registrasi Pengguna yang tidak memenuhi persyaratan ataupun tidak memberikan informasi yang benar dan valid, dan Kami berhak juga mengeluarkan Pengguna Terdaftar dari keanggotaan jika di kemudian hari ditemukan hal-hal yang melanggar ketentuan dari Kami.</p>
                        <p>7.5. Pengguna yang telah sukses melakukan proses registrasi, dan menjadi Pengguna Terdaftar, dapat melakukan akses keanggotaan kapan pun melalui Situs ataupun aplikasi mobile milik Kami.</p>
                        <p>7.6. Semua Pengguna Terdaftar wajib mematuhi Syarat dan Ketentuan yang berlaku di Situs ini, dan tidak diperkenankan melakukan tindakan-tindakan seperti tertuang dalam poin 3.2, baik dalam keanggotaan Situs ataupun partisipasi dalam forum.</p>
                        <h2 class="bold-md f-14 mt-5">8. UMUM
                        </h2>
                        <p>Penggunaan dan akses ke Situs ini diatur oleh Syarat dan Ketentuan serta Kebijakan Privasi Kami. Dengan mengakses atau menggunakan Situs ini, informasi, atau aplikasi lainnya dalam bentuk aplikasi mobile yang disediakan dalam Situs, berarti Anda telah memahami, menyetujui serta terikat dan tunduk dengan segala syarat dan ketentuan yang berlaku di Situs ini.</p>
                        <p>8.2. Kami berhak untuk menutup atau mengubah atau memperbaharui Syarat dan Ketentuan ini setiap saat tanpa pemberitahuan, dan berhak untuk membuat keputusan akhir jika tidak ada ketidakcocokan. Kami tidak bertanggung jawab atas kerugian dalam bentuk apa pun yang timbul akibat perubahan pada Syarat dan Ketentuan.</p>
                        <p>8.3. Jika Anda masih memerlukan jawaban atas pertanyaan yang tidak terdapat dalam Syarat dan Ketentuan ini, Anda dapat menghubungi Kami di email admin@ternakbagus.com atau menghubungi Kami di nomor 0812 5000 3264.</p>

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php

    get_footer();
} else {
    header('location:../');
}
