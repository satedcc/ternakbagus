<?php
session_start();
$sid = session_id();


if (isset($_SESSION['id'])) {
    get_header();

?>

    <section id="dashboard" class="dashboard">
        <div class="container">
            <div class="row">
                <?php include "left-navbar.php"; ?>
                <div class="col-md-9">
                    <h1 class="f-20 mb-3">Tentang Kami</h1>
                    <div class="content-utama p-4">
                        <h1 class="f-18">Tentang <span class="bold-md">Ternakbagus.com</span></h1>
                        <p>Ternakbagus.com adalah sebuah platfom digital yang membantu para pelaku bisnis di bidang perternakan baik berupa hewan ternak dan jasa. Ternakbagus berkomitmen membantu memasarkan secara luas hasil-hasil perternakan dari berbagai pelosok daerah sehingga dapat membantu pelaku bisnis di bidang ternak dalam memasarkan hasil-hasil produknya</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php

    get_footer();
} else {
    header('location:../');
}
