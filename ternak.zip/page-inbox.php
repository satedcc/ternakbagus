<?php
session_start();
$sid = session_id();

if (isset($_SESSION['id'])) {

    $cekuser = $wpdb->get_var("SELECT COUNT(*) FROM wp_chat WHERE receiver_id='" . $_SESSION['member'] . "'");
    if ($cekuser > 0) {
        $memberid = "send_id";
    } else {
        $memberid = "receiver_id";
    }
    get_header();

?>

    <div class="container bars">
        <div class="row">
            <div class="col-md-12 text-right">
                <a href="#" onclick="openNav()">
                    <i class="far fa-bars fa-2x"></i>
                </a>
            </div>
        </div>
    </div>

    <section id="dashboard" class="dashboard">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <?php
                    // $cekuser = $wpdb->get_var("SELECT COUNT(*) FROM wp_chat WHERE receiver_id='" . $_SESSION['member'] . "'");
                    // if ($cekuser > 0) {
                    //     $chats = $wpdb->get_results("SELECT * FROM `wp_chat` LEFT JOIN wp_members ON wp_chat.send_id=wp_members.member_id WHERE chat_id IN (SELECT MAX(chat_id) FROM wp_chat GROUP BY send_id) AND receiver_id='" . $_SESSION['member'] . "' ORDER BY chat_at DESC", ARRAY_A);
                    // } else {
                    //     $chats = $wpdb->get_results("SELECT * FROM `wp_chat` LEFT JOIN wp_members ON wp_chat.send_id=wp_members.member_id WHERE chat_id IN (SELECT MAX(chat_id) FROM wp_chat GROUP BY send_id) AND send_id='" . $_SESSION['member'] . "' ORDER BY chat_at DESC", ARRAY_A);
                    // }

                    $chats = $wpdb->get_results("SELECT * FROM `wp_chat` LEFT JOIN wp_members ON wp_chat.send_id=wp_members.member_id WHERE receiver_id='" . $_SESSION['member'] . "' GROUP BY send_id ORDER BY chat_at DESC", ARRAY_A);

                    foreach ($chats as $c) {
                        if ($c['status_chat'] == "N") {
                            $class = " new";
                        }
                    ?>
                        <div class="menu-inbox">
                            <a href="" class="content-main d-flex align-items-center<?= $class; ?>">
                                <div>
                                    <img src="https://midone.left4code.com/dist/images/profile-3.jpg" alt="" class="img-inbox mr-2">
                                </div>
                                <div class="list-message">
                                    <h1 class="f-14 m-0 bold-md"><?= $c['nama']; ?></h1>
                                    <p class="m-0 f-12"><?= $c['message']; ?></p>
                                    <span class="jam"><?php echo time_ago($c['chat_at']); ?></span>
                                </div>
                            </a>
                        </div>
                    <?php
                    }
                    ?>
                </div>
                <div class="col-md-8">
                    <div class="content-utama">
                        <div class="row justify-content-between p-3">
                            <div class="col-auto d-flex align-items-center">
                                <div>
                                    <img src="https://midone.left4code.com/dist/images/profile-3.jpg" alt="" class="img-inbox mr-2">
                                </div>
                                <div>
                                    <h2 class="f-18 m-0">Gunawan Iqbal</h2>
                                    <span>Hey, i am using chat &middot; Online</span>
                                </div>
                            </div>
                            <div class="col-auto"></div>
                        </div>
                        <hr class="my-2">
                        <div class="body-inbox">
                            <?php
                            $chat_message = $wpdb->get_results("SELECT * FROM wp_chat", ARRAY_A);
                            foreach ($chat_message as $cm) {
                                if ($cm['type_chat'] == "seller") {
                            ?>
                                    <div class="seller p-3 d-flex justify-content-end">
                                        <div class="replay">
                                            <p class="block"><?= $cm['message']; ?></p>
                                            <span class="text-info"><?php echo time_ago($cm['chat_at']); ?></span>
                                        </div>
                                        <div>
                                            <img src="https://midone.left4code.com/dist/images/profile-3.jpg" alt="" class="img-inbox ml-2">
                                        </div>
                                    </div>
                                <?php
                                } else {
                                ?>
                                    <div class="buyer p-3 d-flex">
                                        <div>
                                            <img src="https://midone.left4code.com/dist/images/profile-2.jpg" alt="" class="img-inbox mr-2">
                                        </div>
                                        <div class="chat">
                                            <p class="block"><?= $cm['message']; ?></p>
                                            <span class="text-secondary"><?php echo time_ago($cm['chat_at']); ?></span>
                                        </div>
                                    </div>
                            <?php
                                }
                            }
                            ?>
                            <!-- <div class="buyer p-3 d-flex">
                                        <div>
                                            <img src="https://midone.left4code.com/dist/images/profile-2.jpg" alt="" class="img-inbox mr-2">
                                        </div>
                                        <div class="chat">
                                            <p class="block">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error, necessitatibus?</p>
                                            <span class="text-secondary">2 jam lalu</span>
                                        </div>
                                    </div>
                                    <div class="seller p-3 d-flex justify-content-end">
                                        <div class="replay">
                                            <p class="block">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error, necessitatibus?</p>
                                            <span class="text-secondary">2 jam lalu</span>
                                        </div>
                                        <div>
                                            <img src="https://midone.left4code.com/dist/images/profile-3.jpg" alt="" class="img-inbox ml-2">
                                        </div>
                                    </div>
                                    <div class="buyer p-3 d-flex">
                                        <div>
                                            <img src="https://midone.left4code.com/dist/images/profile-3.jpg" alt="" class="img-inbox mr-2">
                                        </div>
                                        <div class="chat">
                                            <p class="block">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error, necessitatibus?</p>
                                            <span class="text-secondary">2 jam lalu</span>
                                        </div>
                                    </div>
                                    <div class="seller p-3 d-flex justify-content-end">
                                        <div class="replay">
                                            <p class="block">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error, necessitatibus?</p>
                                            <span class="text-secondary">2 jam lalu</span>
                                        </div>
                                        <div>
                                            <img src="https://midone.left4code.com/dist/images/profile-2.jpg" alt="" class="img-inbox ml-2">
                                        </div>
                                    </div>
                                    <div class="seller p-3 d-flex justify-content-end">
                                        <div class="replay">
                                            <p class="block">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error, necessitatibus?</p>
                                            <span class="text-secondary">2 jam lalu</span>
                                        </div>
                                        <div>
                                            <img src="https://midone.left4code.com/dist/images/profile-2.jpg" alt="" class="img-inbox ml-2">
                                        </div>
                                    </div> -->
                        </div>
                        <hr class="my-2">
                        <div class="row p-3 justify-content-between align-items-center">
                            <div class="col-md-8">
                                <input type="text" name="" id="" placeholder="masukkan pesan anda..." class="w-100">
                            </div>
                            <div class="col-md-auto">
                                <label for="photo"><i class="far fa-paperclip f-20 text-secondary mr-4"></i></label>
                                <input type="file" name="photo" id="photo">
                                <button class="glow-btn">
                                    <i class="far fa-paper-plane mr-2"></i>Kirim Pesan
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php

    get_footer();
} else {
    header('location:../');
}
